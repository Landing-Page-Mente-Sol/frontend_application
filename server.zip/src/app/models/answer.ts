export interface Answer {
  descripcion: string,
  fecha: Date|string,
  autor: string,
  index_pregunta: number
  id: number
}
