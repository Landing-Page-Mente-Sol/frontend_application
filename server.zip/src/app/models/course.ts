export interface Course {
  curso: string,
  imagen: string
}
