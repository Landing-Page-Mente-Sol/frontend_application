export interface Recursos_Buscar {
  buscar:string
}
