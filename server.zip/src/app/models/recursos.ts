export interface Recursos {
  numero:number
}
