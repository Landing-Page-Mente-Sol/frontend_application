export interface Tuple {
  llave: string,
  valor: string
}
