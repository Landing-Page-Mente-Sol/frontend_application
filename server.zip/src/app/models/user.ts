import {Tuple} from "./tuple";
export interface User {
  id: number,
  dates: Tuple[]
}
