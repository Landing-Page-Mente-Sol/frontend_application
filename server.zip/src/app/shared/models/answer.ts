export interface Answer {
  descripcion: string,
  fecha: string,
  autor: string,
  index_pregunta: number
}
